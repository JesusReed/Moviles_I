package com.example.eva1_7_radiogroup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioGroup rdGrpComida;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rdGrpComida = findViewById(R.id.rdgComida);
        //Asignar el Listener
        rdGrpComida.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                /*switch (i){
                    case R.id.radioButton:
                        Toast.makeText(MainActivity.this, "Montados",Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton2:
                        Toast.makeText(MainActivity.this, "Burritos",Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton3:
                        Toast.makeText(MainActivity.this, "Alitas",Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton4:
                        Toast.makeText(MainActivity.this, "Garnachas",Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton5:
                        Toast.makeText(MainActivity.this, "Tacos",Toast.LENGTH_LONG).show();
                        break;
                    case R.id.radioButton6:
                        Toast.makeText(MainActivity.this, "Pollito",Toast.LENGTH_LONG).show();
                        break;
                    default:
                }*/
                RadioButton rdBtnSel;
                rdBtnSel = findViewById(i);
                Toast.makeText(getApplicationContext(), rdBtnSel.getText(),Toast.LENGTH_LONG).show();

            }
        });

    }
}