package com.example.eva1_4_find_view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.service.autofill.TextValueSanitizer;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txtViewMessage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //HAY QUE CONECTAR ANTES
        txtViewMessage = findViewById(R.id.txtViewMessage);
        txtViewMessage.setText("Hola mundo");
    }
}