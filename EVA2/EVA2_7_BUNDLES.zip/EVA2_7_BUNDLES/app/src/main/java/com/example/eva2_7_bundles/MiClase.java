package com.example.eva2_7_bundles;

import java.io.Serializable;

class MiClase implements Serializable {
    private int param1;
    private int param2;

    public int getParam2() {
        return param2;
    }

    public int getParam1() {
        return param1;
    }

    public void setParam1(int param1) {
        this.param1 = param1;
    }

    public void setParam2(int param2) {
        this.param2 = param2;
    }
}