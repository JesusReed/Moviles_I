package com.example.eva2_7_bundles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.io.Serializable;

public class MainActivity extends AppCompatActivity {

    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intent = new Intent(this, OtraActivity.class);
    }

    public void onClick(View view) {
        MiClase miClase = new MiClase();
        miClase.setParam1(100);
        miClase.setParam2(200);
        Bundle bundle = new Bundle();
        bundle.putString("MENSAJE", "Hola mundo");
        bundle.putInt("EDAD", 100);
        bundle.putBoolean("EMPLEADO", true);
        //bundle.putParcelable();
        bundle.putSerializable("PRUEBA", miClase);
        intent.putExtras(bundle);
        startActivity(intent);
    }

}