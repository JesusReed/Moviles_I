package com.example.eva2_5_extras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    EditText edtTxtNom, edtTxtSal;
    CheckBox chkBxInfo;
    RadioButton rdBtnSol, rdBtnCas, rdBtnDiv, rdBtnEtc;
    Intent intent;
    RadioGroup rdGpEdoCiv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intent = new Intent(this, SecundariaActivity.class);
    }
    @Override
    protected void onStart() {
        super.onStart();
        edtTxtNom = findViewById(R.id.edtTxtNom);
        edtTxtSal = findViewById(R.id.edtTxtSal);
        chkBxInfo = findViewById(R.id.chkBxInfo);
        rdBtnSol = findViewById(R.id.rdBtnSol);
        rdBtnCas = findViewById(R.id.rdBtnCas);
        rdBtnDiv = findViewById(R.id.rdBtnDiv);
        rdBtnEtc = findViewById(R.id.rdBtnSinInf);
        rdGpEdoCiv = findViewById(R.id.rdGpEdoCiv);

    }

    public void onClickEnv(View view) {
        intent.putExtra("NOMBRE",edtTxtNom.getText().toString());
        Double dSalario = 0.0;
        dSalario = Double.parseDouble(edtTxtSal.getText().toString());
        intent.putExtra("SALARIO", dSalario);
        intent.putExtra("INFO", chkBxInfo.isChecked());
        intent.putExtra("ESTADO_CIVIL", rdGpEdoCiv.getCheckedRadioButtonId());
        startActivity(intent);
    }
}