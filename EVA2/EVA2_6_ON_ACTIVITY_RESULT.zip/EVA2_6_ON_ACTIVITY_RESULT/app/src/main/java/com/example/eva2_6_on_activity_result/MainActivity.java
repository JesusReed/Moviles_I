package com.example.eva2_6_on_activity_result;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    final static int CODIGO_SECUN = 1000;
    final static int CODIGO_CONT = 1001;
    final static int CODIGO_EXTRA = 1002;
    Button btnIniSecun, btnCont, btnExtra;
    Intent intent, intentCont, intentExtra;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intent = new Intent(this, SecundariaActivity.class);
        intentCont = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        intentExtra = new Intent(Intent.ACTION_PICK, Uri.parse("content://media/external/images/media"));
    }

    @Override
    protected void onStart() {
        super.onStart();
        btnIniSecun = findViewById(R.id.btnIniSecun);
        btnCont = findViewById(R.id.btnCont);
        btnExtra = findViewById(R.id.btnExtra);
        btnIniSecun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(intent); ESTO YA NEL
                intent.putExtra("DATOS", "Información enviada desde principal");
                startActivityForResult(intent, CODIGO_SECUN);
            }
        });
        btnCont.setOnClickListener(this::onClickCont);
        btnExtra.setOnClickListener(this::onClickExtra);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //AQUI SE PROCESA LA RESPUESTA DE LA ACTIVIDAD
        //IDENTIFICAR LA ACTIVIDAD QUE DEVOLVIÓ EL RESULTADO
        //IDENTIFICAR SI SE DEVOLVIÓ UN VALOR O NO
        //LEER LOS DATOS (INTENT)
        switch (requestCode){
            case CODIGO_SECUN:
                if (resultCode == Activity.RESULT_OK){
                    //LEER LOS DATOS
                    Toast.makeText(this, data.getStringExtra("VALOR"),Toast.LENGTH_LONG).show();
                }
                break;
            /*case CODIGO_ETCETERA: un caso para cada actividad que regresa un valor
                break;*/
            case CODIGO_CONT:
                if (resultCode == Activity.RESULT_OK){
                    //LEER LOS DATOS
                    String returnedData = data.getDataString();
                    Toast.makeText(this, returnedData,Toast.LENGTH_LONG).show();
                }
                break;
            case CODIGO_EXTRA:
                if (resultCode == Activity.RESULT_OK){
                    String returnedData = data.getDataString();
                    Toast.makeText(this, returnedData,Toast.LENGTH_LONG).show();
                    //ES PRACTICAMENTE EL MISMO CODIGO
                }
            default:
        }

    }

    public void onClickCont(View view) {
        startActivityForResult(intentCont, CODIGO_CONT);
    }

    public void onClickExtra(View view) {
        startActivityForResult(intentExtra, CODIGO_EXTRA);
    }
}