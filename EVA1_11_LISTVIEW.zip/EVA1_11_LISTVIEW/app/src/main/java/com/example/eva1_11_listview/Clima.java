package com.example.eva1_11_listview;

public class Clima {
    private int imagen;
    private double temp;
    private String ciudad, desc;

    public Clima() {
        this.imagen = R.drawable.sunny;
        this.temp = 25.2;
        this.ciudad = "Campeche";
        this.desc = "Ta comoda la wea jsjs";
    }

    public Clima(int imagen, double temp, String ciudad, String desc) {
        this.imagen = imagen;
        this.ciudad = ciudad;
        this.temp = temp;
        this.desc = desc;
    }

    public int getImagen() {
        return imagen;
    }

    public double getTemp() {
        return temp;
    }

    public String getCiudad() {
        return ciudad;
    }

    public String getDesc() {
        return desc;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }

    public void setTemp(double temp) {
        this.temp = temp;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
