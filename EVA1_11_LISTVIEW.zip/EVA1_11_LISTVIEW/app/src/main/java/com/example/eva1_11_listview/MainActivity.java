package com.example.eva1_11_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{

    Clima[] aClimaCd = {
            new Clima(R.drawable.sunny, 28, "Madera", "Soleado"),
            new Clima(R.drawable.cloudy, 20, "Ola beibi", "No hay soleado"),
            new Clima(R.drawable.light_rain, 18, "Jimenez", "Feo"),
            new Clima(R.drawable.snow, -5, "Juarez", "Nevado"),
            new Clima(R.drawable.cloudy, 21, "Camargo", "Nublado"),
            new Clima(R.drawable.atmospher, 19, "Casas Grandes", "Humedo"),
            new Clima(R.drawable.cloudy, 15, "Ahumada", "Nublado"),
            new Clima(R.drawable.sunny, 30, "Parral", "Soleado"),
            new Clima(R.drawable.sunny, 35, "Cuahutemoc", "Soleado"),
            new Clima(R.drawable.snow, -10, "Chihuauha", "A nu ma esta nevado xd"),
            new Clima(R.drawable.thunderstorm, 17, "Creel", "Al tiro que te cae un rayo"),
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }
}