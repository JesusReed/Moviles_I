package com.example.eva1_11_listview;

import android.content.Context;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;

public class ClimaAdaptador extends ArrayAdapter<Clima>{

    public ClimaAdaptador(@NonNull Context context, int resource, @NonNull Clima[] objects) {
        super(context, resource, objects);
    }
}
