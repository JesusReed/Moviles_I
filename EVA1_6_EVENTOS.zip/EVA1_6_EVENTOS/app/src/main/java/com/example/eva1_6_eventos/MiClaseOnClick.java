package com.example.eva1_6_eventos;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MiClaseOnClick implements View.OnClickListener {
    Context conext;

    public void setConext(Context conext) {
        this.conext = conext;
    }

    @Override
    public void onClick(View v) {
        Toast.makeText(conext,"EVENTO POR CLASE", Toast.LENGTH_LONG).show();
        Log.wtf("APP", "EVENTO POR CLASE");
    }
}
