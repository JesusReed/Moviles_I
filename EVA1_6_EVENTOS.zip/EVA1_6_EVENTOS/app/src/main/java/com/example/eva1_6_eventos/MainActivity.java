package com.example.eva1_6_eventos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnListener, btnClaseAnonima, btnPorClase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnListener = findViewById(R.id.btnListener);
        btnListener.setOnClickListener(this);
        btnClaseAnonima = findViewById(R.id.btnClaseAnonima);
        btnClaseAnonima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "EVENTO POR CALSE ANÓNIMA", Toast.LENGTH_LONG).show();
            }
        });

        MiClaseOnClick objClick = new MiClaseOnClick();
        objClick.setConext(this);
        btnPorClase = findViewById(R.id.btnPorClase);
        btnPorClase.setOnClickListener(objClick);
    }

    //Utilizar la propiedad android:onclick del widget en XML
    //public void Nombredelmetodo(view arg){}
    //Un objeto de tipo view es: una clase, area rectangular donde se dibuja el widget,
    public void miClick(View arg){
        //Mostrar un mensaje (Toast)
        Toast.makeText(this, "EVENTO POR ONCLICK XML", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onClick(View view) {
        Toast.makeText(this, "EVENTO POR LISTENER", Toast.LENGTH_LONG).show();
    }
}

interface algo{
    public void miClick(View arg);
}