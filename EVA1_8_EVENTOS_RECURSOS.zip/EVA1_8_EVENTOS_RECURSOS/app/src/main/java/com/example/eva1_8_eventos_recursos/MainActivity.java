package com.example.eva1_8_eventos_recursos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {
    TextView txtNom, txtApe;
    EditText edtTxtNom, edtTxtApe;
    RadioGroup rdGrpIdioma;
    RadioButton rdBtnEs, rdBtnIn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtNom = findViewById(R.id.txtNom);
        txtApe = findViewById(R.id.txtApe);
        edtTxtNom = findViewById(R.id.edtTtxtNom);
        edtTxtApe = findViewById(R.id.edtTtxtApe);
        rdGrpIdioma = findViewById(R.id.rdGrpIdioma);
        rdBtnEs = findViewById(R.id.rdBtnEs);
        rdBtnIn = findViewById(R.id.rdBtnIn);
        rdGrpIdioma.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int i) {
        if(i == R.id.rdBtnEs){
            txtNom.setText(R.string.txt_nom_es);
            txtApe.setText(R.string.txt_ape_es);
            edtTxtNom.setHint(R.string.edt_txt_nom_es);
            edtTxtNom.setHint(R.string.edt_txt_nom_es);
            rdBtnEs.setText(R.string.rd_btn_es);
            rdBtnIn.setText(R.string.rd_btn_in);

        }else{
            txtNom.setText(R.string.txt_nom_en);
            txtApe.setText(R.string.txt_ape_en);
            edtTxtNom.setHint(R.string.edt_txt_nom_en);
            edtTxtNom.setHint(R.string.edt_txt_nom_en);
            rdBtnEs.setText(R.string.rd_btn_es_en);
            rdBtnIn.setText(R.string.rd_btn_in_en);
        }
    }
}